<?= $this->extend('template') ?>

<?= $this->section('content') ?>
<h1 class="text-dark">About Page</h1>
<p>This is the About page.</p>
<?= $this->endSection() ?>