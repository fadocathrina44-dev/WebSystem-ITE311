<?= $this->extend('template') ?>

<?= $this->section('content') ?>
<h1 class="text-dark">Contact Page</h1>
<p>This is our Contact page.</p>
<?= $this->endSection() ?>