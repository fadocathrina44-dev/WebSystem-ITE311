<?= $this->extend('template') ?>

<?= $this->section('content') ?>
<h1 class="text-dark">Welcome to the Homepage</h1>
<p>This is the Homepage.</p>
<?= $this->endSection() ?>